/**
 * MLStree_starter.c - Starter source code file for MLS binary tree
 *
 * Author: Roy Kravitz (roy.kravitz@pdx.edu)
 * Date: 30-Oct-2020
 * 
 * This is starter source code for a binary tree ADT targeted to the
 * MLS standings app (ECE 361 hw3).  You need to develop the four
 * functions that say // ADD CODE HERE
 *
 * @note code is based on the BinarySearchTree example used during
 * the ECE 361 lectures 
 *
 * @note This is a reasonably sized subset of my binary tree ADT.  You
 * can build on this or go in your own direction.  You are the softare
 * engineer on this project.  If you decide to go your own way, it is 
 * in your benefit to preserve the structure of the prototypes in MLStree.harderr
 * because they are used in test_MLStree.c
 */

 // Reference //https://www.geeksforgeeks.org/tree-traversals-inorder-preorder-and-postorder/

 
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "MLStree.h"
#include"MLSapp_Helpers.h"

 
 /**
 * createMLStree() - creates an MLS tree 
 *
 * @param	cont				Eastern or Western conference
 * @param	numTeams			Number of teams in the conference
 * @param 	numPlayoffTeams		Number of teams qualifying for playoffs
 *
 * @return	a pointer to the new MLStree if it succeeds.  NULL if it fails.
 * root node is NULL to start with because the tree has 0 nodes
 *
 */
 MLStreePtr_t createMLStree(MLSconf_t conf, int numTeams, int numPlayoffTeams) 
 {
	MLStreePtr_t temp = (MLStreePtr_t)malloc(sizeof(MLStreePtr_t)); 
	if (temp == NULL) 
	{
		#if (_VERBOSE_ > 0)
			printf("ERROR(createMLSTree()): Could not allocate space for MLStree\n");
		#endif		
		return NULL;
	}
	
	// initialize the tree struct
	temp->conf = conf;
	temp->numTeams = numTeams;
	temp->numPlayoffTeams = numPlayoffTeams;
	temp->root = NULL;
	
	// ADD YOUR CODE HERE
	return temp;
}

TreeNodePtr_t buildMLStree(MLStreePtr_t west_conf, MLStreePtr_t east_conf)
{
	FILE *f;
	char buffer[256];
	int counter = 0;
	TreeNodePtr_t temp;
	TreeNodePtr_t data;
	if((f = fopen("MLS2020.txt", "r")) == NULL)
	{
		perror("Opening title file");
	}
	else 
	{
	        temp = (TreeNodePtr_t)malloc(sizeof(TreeNode_t));
		while (fgets(buffer, 256, f) != NULL)
		{
			buffer[strlen(buffer) - 1] = '\0'; // trim off newline character
			//printf("%3d: \"%s\"\n", ++counter, buffer);
			
			TeamInfoPtr_t tp = (TeamInfoPtr_t)malloc(sizeof(TeamInfo_t));
			parseTeamInfo(buffer, tp);
			if(tp->conf == 1)
			{
				// inserting team in west conf
				data = insert(west_conf,*tp);

			}
			else 
			{
				// inserting node in east if enumarator=0 
				data = insert(east_conf,*tp);
			}
			//printf("Parsing MLS data base file\n");
			//parseTeamInfo(buffer, tp);
		}
  }
	fclose(f);
	return temp;
}

/**
 * insert() - inserts a new team info record into the tree
 *
 * @param	tree	pointer to the MLStree to add the node to
 * @param	info	team info record to add
 * @return	pointer to the new tree node

 * @note Not a good idea to expose the data node but w/o a pointer to
 * root I don't see much harm and it could be useful...and, in fact, INFO
 * made use of it several times in my application
 */
TreeNodePtr_t insert(MLStreePtr_t tree, TeamInfo_t info) 
{

	TreeNodePtr_t	 tempNodePtr;		// pointer to a new node
	TreeNodePtr_t	 current, parent;	// pointers to traverse the tree

  tempNodePtr =(TreeNodePtr_t)malloc(sizeof(TreeNode_t));
  tempNodePtr->info = info; 
	tempNodePtr->leftChild= NULL;
	tempNodePtr->rightChild= NULL;
	
	// make sure there is a tree
	if (tree == NULL) {
		#if (_VERBOSE_ > 0)
			printf("ERROR(insert(): Not a valid MLS tree\n");
		#endif		
		return NULL;
	}
	
	// add and populate the new node to the tree
	
	if(tree ==NULL)
	{  
		printf("tree not inserted");
	}
	

	if(tree->root == NULL)
	{
		tree->root =tempNodePtr;
	}
	else 
	{
		current= tree->root;
		parent = NULL;
		while(1)
		{	//insert node base on ppg
                    parent = current;
                    if(tree->root->info.ppg < parent->info.ppg)
                    {
                            current = current->leftChild;
                            if (current == NULL)
                            {
                              parent->leftChild =tempNodePtr;
                              return NULL;
                            }
                    }
                    else 
                    {	    
                            current = current->rightChild;
                            if(current == NULL)
                            {
                              parent->rightChild = tempNodePtr;
                              return NULL;
                            }
                    }
		}
	}
	// ADD YOUR CODE HERE
	
		
	// insert the node based on the PPG (points per game) because PPG 
	// is being used in the MLS 2020 season to determine the standings.
	// The binary tree should be built with the PPG of the leftChild <
	// PPG of its parent node and the PPG of the rightChild > the PPG of
	// its parent node.
	// Study the sample code provided to design this function
	
	// ADD YOUR CODE HERE
	return tempNodePtr;
}


TreeNodePtr_t pickTop(MLStreePtr_t tree) //traverse to the most right of tree 
{
	TreeNodePtr_t temp = tree->root;
	while(tree->root<temp->rightChild)
  {
		temp = temp->rightChild; // go to the mos right and get the highest value 
  }
	return temp;
}

/**
 * printStandings() - prints the standings (table)
 *
 * @param	tree	pointer to the MLStree to search
 *
 * @note teams that qualify for the playoffs get an x in the first column
 *
 * @note function should do a reverse in-order traversal since we want the
 * teams listed from highest PPG to lowest PPG.  
 * Try to mimic the Table entries shown in the hw3_results.txt file.  It's
 * going to take some playing around and likely lots of compiles to get the
 * formatting to where you like it.  That's why writing a makefile for this
 * assignment will be helpful. 
 */


void printInorder(TreeNodePtr_t root,int numPlayoffteams) 
{ 
     if (root == NULL) 
          return; 

      int count = 1;
    
    
    printInorder(root->leftChild,numPlayoffteams);
     printf("%d",count++);
     printf("%29s", root->info.name);
     printf("%5d " , root->info.pts);
     printf("%5.2f " , root->info.ppg);
     printf("%5d " , root->info.gp);
     printf("%3d " , root->info.win);
     printf("%3d " , root->info.loss);
     printf("%3d \n" , root->info.tie);
    printInorder(root->rightChild,numPlayoffteams); 
  
}
  

 void printStandings(MLStreePtr_t tree) 
{
	TreeNodePtr_t	current;	// pointer to traverse the tree

	// Study the sample code to get an idea of how to do a recursive
	// in-order traversal
  
  char arr[] = "Club";
  char arr1[] = "Pts";
  char arr2[] = "PPG";
  char arr3[] = " GP";
  char arr4[] = " W";
  char arr5[] = " L";
  char arr6[] = " T";

  printf("\n#");
  printf("%29s", arr);
  printf("%5s " , arr1);
  printf("%5s", arr2);
  printf("%5s " , arr3);
  printf("%4s", arr4);
  printf("%4s " , arr5);
  printf("%3s\n", arr6);
 
  
  printInorder(tree->root,tree->numPlayoffTeams);
	printf("NOTE: x - team has qualified for the Playoffs\n");
	
	
}
